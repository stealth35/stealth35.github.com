
The tools provided in this archive come fromt the following projetcs:

* Zip Tools
 http://www.info-zip.org/ 

 Various tools to work with zip archives.

 Files:
  funzip.exe
  SFXWiz32.exe
  unzip.exe
  unzip32.dll
  zipfino.exe

* Jam
 http://freetype.sourceforge.net/jam/index.html
 
 Makefile-like system, based on perfoce's jam (used by freetype).

 Files:
  jam.exe


* Prjconverter
 http://www.codeproject.com/KB/applications/prjconverter.aspx

 Tools to convert VC7+ project files to VC6 projects.

 Files:
  prjconverter.exe



* re2c: http://re2c.sourceforge.net/

 Tool to write scanners
 Files:
  re2c.exe


* flex:
 http://gnuwin32.sourceforge.net/packages/flex.htm

 Flex is a fast lexical analyser generator

 Files:
  flex.exe



* Bison
 http://gnuwin32.sourceforge.net/packages/bison.htm

 Yacc-compatible parser generator

 Files:
  bison.exe
  bison.simple